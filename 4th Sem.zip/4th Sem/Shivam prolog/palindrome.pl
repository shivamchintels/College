palindrome([]).
palindrome([X]).
palindrome(L1):-rev(L1,[],L2),
    comp(L1,L2).
rev([],L1,L2).
rev([H|T],L2,L3):-rev(T1,[H|L2],T2).
comp([],[]):-write("Given List is palindrome").
comp([H|T1],[H|T2]):-comp(T1,T2).
comp([H|T1],[X|T2]):-write("Given List is not Palindrome").

