
import java.util.*;

/**
 * 
 */
public class Demo2 extends Demo {

    /**
     * Default constructor
     */
    public Demo2() {
    }

    /**
     * 
     */
    public void int y;

    /**
     * 
     */
    public void Operation1() {
        // TODO implement here
    }

}