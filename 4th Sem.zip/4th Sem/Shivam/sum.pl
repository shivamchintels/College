sum:-write("Enter the value of X"),
    read(X),
    write("Enter value of Y"),
    read(Y),
    Z is X+Y,
    write("Sum is "),
    write(Z).

