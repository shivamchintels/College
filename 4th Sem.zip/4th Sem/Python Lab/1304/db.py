import cx_Oracle

conn=cx_Oracle.connect("shivam/shivam");
cur= conn.cursor();

dataset=[(100,'Shivam',3000,'TOP','Knapur', 'Area')]

cursor