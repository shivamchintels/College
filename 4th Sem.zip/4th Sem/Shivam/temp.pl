temp():-
     write("Enter temp in F"),
     read(F),
     C is (F-32)*(5/9),
     write("Temperauture in Celcius is"),
     write(C).
