
public class TGP implements Runnable
{
public void run()
{
	 System.out.println(Thread.currentThread().getName());
}
public static void main(String args[])
{
	TGP obj= new TGP();
	ThreadGroup tg1=new ThreadGroup("Group A");
	Thread t1= new Thread(tg1, obj,"1");
	t1.start();
	Thread t2= new Thread(tg1, obj,"2");
	t2.start();
	Thread t3= new Thread(tg1, obj,"3");
	t3.start();
	 System.out.println("Thread.Groupname:"+tg1.getName());
	 tg1.list();

	 ThreadGroup tg2=new ThreadGroup("Group B");
		Thread t4= new Thread(tg2, obj,"1");
		t4.start();
		Thread t5= new Thread(tg2, obj,"2");
		t5.start();
		Thread t6= new Thread(tg2, obj,"3");
		t6.start();
		 System.out.println("Thread.Groupname:"+tg1.getName());
		 tg1.list();
}
}
