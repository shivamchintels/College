 public class Tm extends Thread
{
 public void run()
 {
 System.out.println("task one");
}
public static void main()
{
	Tm t1=new Tm();
	Tm t2=new Tm();
	 
	Tm t3=new Tm();
	 
	 
	t1.start();
	t2.start();
	t3.start();
}}