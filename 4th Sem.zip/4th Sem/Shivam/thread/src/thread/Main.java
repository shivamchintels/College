package thread;
class Mythread extends Thread
{
		public void run()
		{int i;
		System.out.println("Child Thread");
			for(i=1;i<=10;i++)
			{
				System.out.println(i);
			}
		}
	}
public class Main {

	public static void main(String[] args) 
	{
		int i;
		Mythread t1=new Mythread();
		t1.start();
		for(i=10;i>=0;i--)
		{
			System.out.println(i);
		}
		
	}

}
