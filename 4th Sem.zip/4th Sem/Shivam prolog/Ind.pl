Ind(X,[],[X]).
Ind(X,[H|T],[H1|T1]):-
Ind(X,T,T1).
