
import java.util.*;

/**
 * 
 */
public class Demo {

    /**
     * Default constructor
     */
    public Demo() {
    }

    /**
     * 
     */
    public void int x;

    /**
     * 
     */
    public void void show() {
        // TODO implement here
    }

}