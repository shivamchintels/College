package click;

public class Click3 {

	public static void main(String[] args) {
		try{
			int a=10/0;
			System.out.println(a);
		}
		catch(ArithmeticException e1)
		{
			System.out.println("Divide by 0");
		}
		catch(Exception e)
		{
			System.out.println("File not found");
		}
		
	}

}
