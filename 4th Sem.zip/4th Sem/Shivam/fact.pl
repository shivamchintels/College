fact(0,1).
fact(N,K):- K1 is N-1,
    fact(K1,R),
    K is N*R.
