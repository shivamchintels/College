male(allen).
male(charles).
male(bobby).
male(ivian).

female(eber).
female(elie).
female(marry).
female(sally).
mother(marry,eber).
mother(sally,allen).
father(allen,bobby).
father(allen,marry).
parent(X,Y):-father(X,Y).
parent(X,Y):-mother(X,Y).
brother(X,Y):-parent(A,X),
    parent(A,Y),male(X).



