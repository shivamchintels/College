pow(N,0,1).
pow(N,K,R):- K1 is K-1,
    pow(N,K1,S),
    R is N*S.
