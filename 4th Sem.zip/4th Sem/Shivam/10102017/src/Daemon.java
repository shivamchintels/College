public class Daemon extends Thread{
 public void run()
 {
	 if(Thread.currentThread().isDaemon())
	 {
		 System.out.println("daemon thread work");
	 }
	 else
	 {
		 System.out.println("user thread work");
	 }}
 public static void main(String args[])
 {
	 Daemon t1= new Daemon();
	 Daemon t2= new Daemon();
	 Daemon t3= new Daemon();
	 Daemon t4= new Daemon();
	 t1.setDaemon(false);
	 t1.start();
	 t2.start();
	 t3.start();
	 t4.start();
	 
 }
}
