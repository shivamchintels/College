class Demo
{
int x,y;
void show()
{
}
}
