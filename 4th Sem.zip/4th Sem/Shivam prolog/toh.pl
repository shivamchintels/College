toh(1,1).
toh(N,A):- N1 is N-1,
          toh(N1,R1),
           A is (2*R1)+1.
