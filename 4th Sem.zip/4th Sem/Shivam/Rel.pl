
    likes(jack,tennis).
    likes(john,football).
    likes(tom,basketball).
    likes(christ,swimming).
    likes(mark,tennis).

    likes(jack,X):-likes(X,tom).




