student(peter,9).
student(paul,10).
student(bob,11).
