sumnum(1,1).
sumnum(A,R):-
    A1 is A-1,
sumnum(A1,R1),
    R is R1+A.

