del(X,[X|T],T).
dael(X,[H|T],[H,T1]):-del(X,T,T1).
