

package click;
import java.util.Scanner;


public class click2 {
	public static void main(String[] args) {
		int a[] =new int[5];
		int i;
		Scanner sc= new Scanner (System.in);
		System.out.println("Enter Elements ");
		try{
				for(i=0;i<7;i++)
				{
					a[i]=sc.nextInt();
				}
		}
		catch(Exception e)
		{
			System.out.println("out of bound");
		}
		finally{
				System.out.println("Elements are:");
				for(i=0;i<7;i++)
				{
					System.out.println(a[i]);
				}
		}
	}
}