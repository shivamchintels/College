parent(shyam,geeta).
parent(amit,shyam).
parent(shyam,rita).
parent(amit,geeta).
parent(geeta,sheena).
related(X,Y):-parent(X,Y).
related(X,Z):-parent(X,Y),
   related(Y,Z).
