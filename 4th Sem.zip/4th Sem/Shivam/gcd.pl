gcd(N,0,N).
gcd(A,B,M):-
    A1 is A mod B,
    gcd(B,A1,M).
