append([],L2,L2).
append(L1,[],L1).
append([],[],[]).
append([H|T],L2,[H|L3]):- append(T,L2,L3).

