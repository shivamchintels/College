length([],0).
length([X|T],L):-length(T,L1),
    L=L1+1.
Number(A):- Lmod2=:=0,
    write("Even no.");
    write("Odd no.").
check([H|T]):-
    length([H|T],B),
    Numer(B).
