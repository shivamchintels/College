pn():-
    write("Enter a value"),
    read(A),
    (   A>0),
    write("Positive Number"),
    (   A=:=0)
    write("Number is zero"),
    write("Number is Negative").
