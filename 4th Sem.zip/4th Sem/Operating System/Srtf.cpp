#include<stdio.h>
int main()
{
		//Inputs
		 int at[10],bt[10],rt[10],endtime,i,smallest;
	      int remain=0,n,time,sum_wait=0,sum_tat=0;
		printf("\nEnter the No. of processes :");
		scanf("%d",&n);
    for(i=0;i<n;i++)
     {
		printf("\tPlease Enter the burst time of %d process :",i+1);
		scanf(" %d",&bt[i]);
		printf("\tPlease Enter the arrival time of %d process :",i+1);
		scanf(" %d",&at[i]);
		rt[i]=bt[i];
}
		printf("\n \n Process \t |TAT| WT \n\n");
		rt[9]=100;
		//Compare Least Remaing Time and Arrival Time
     	for (time=0;remain!=n;time++)
{
		smallest=9;
		for(i=0;i<n;i++)
	
	{
		if(at[i]<=time && rt[i]<rt[smallest] && rt[i]>0)
{
	smallest=i;
}
	}
      rt[smallest]--;
    if(rt[smallest]==0)
{
	remain ++;
	endtime=time+1;
	printf("\n P[%d] \t|\t %d \t|\t %d",smallest+1,endtime-at[smallest],endtime-bt[smallest]-at[smallest]);
	sum_wait+=endtime-bt[smallest]-at[smallest];
	sum_tat+=endtime-at[smallest];
  }
    }
    printf("\n \n Average Waiting Time =%f \n",sum_wait*1.0/n);
    printf("\n \n Average Turnaround Time =%f \n",sum_tat*1.0/n);
    return 0;
}
    
 
 

