nthelement([H|T],1,H).
nthelement([H|T],N,X):-
    N1 is N-1,
    nthelement(T,N1,X).
