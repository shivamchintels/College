package click;

public class Odd {

	public static void main(String[] args) {
		
	}

}
