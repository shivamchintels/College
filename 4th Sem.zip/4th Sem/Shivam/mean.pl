mean():-
    write("Enter A"),
    read(A),
     write("Enter B"),
    read(B),
    S is ((A+B)/2),
    write("Mean is"),
    write(S).
