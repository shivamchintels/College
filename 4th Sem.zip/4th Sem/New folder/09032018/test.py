PI=3.14;
radius=25;
def cal_circum(PI,radius):
    return 2*PI*radius
def cal_area(PI,radius):
    return PI*(radius **2)

 circum: cal_circum(PI, radius)
 print("Circumference is",circum)
 print("Area is",area)