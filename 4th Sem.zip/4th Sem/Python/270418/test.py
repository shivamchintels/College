import cx_Oracle
connect=cx_Oracle.connect("Shiv/Shiv@XE")
cursor = connect.cursor()
cursor.execute("CREATE  TABLE employee(empid NUMBER PRIMARY KEY,name VARCHAR(30),salary NUMBER,location VARCHAR(50),contact NUMBER)")
connect.commit()
connect.close()

CONN=cx_Oracle.connect("Shiv/Shiv@XE")
cursor=CONN.cursor()
##
n=int(input("give inputs for the count of employees (10-15 only)"))
if(n<15 and n>10):
    for i in range(0,n):
        employeeid=int(input("Enter employee_id"))
        name=input("Enter employee_name")
        salary=int(input("Enter employee_salary"))
        location=input("Enter_location")
        contact=int(input("Enter contact_number"))

        data=(employeeid,name,salary,location,contact)
        cursor.execute("""insert into employee values(:1,:2,:3,:4,:5)""",data)

CONN.commit()
cursor.close()
CONN.close()

##
CONN=cx_Oracle.connect("Shiv/Shiv@XE")
cursor=CONN.cursor()

eid=int(input("Enter employee id"))
cursor.execute("""select * from employee where empid=""" + str(eid))
data=cursor.fetchall()
print(data)
cursor.close()
CONN.close()

##---------------------------------------------------------------------------------Q3-----------------------------------------------------------------------------------

CONN=cx_Oracle.connect("Shiv/Shiv@XE")
cursor=CONN.cursor()

employeeid=int(input("Enter the employee id"))
name = input("enter new name: ")
salary = int(input("enter salary: "))
location = input("enter new location: ")
contact = int(input("enter new contact no: "))

data = (employeeid, name, salary, location, contact)
cursor.execute("""update employee set name = :1, salary = :2, location = :3, contactno = :4 where empid = :5""", data)

CONN.commit()
cursor.close()
CONN.close()