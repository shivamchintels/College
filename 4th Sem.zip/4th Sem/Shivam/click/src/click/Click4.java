package click;

public class Click4 {

	public static void main(String[] args) {
		int i;
		for(i=5;i<=0;i--)
		{
			System.out.println(10/i);
		}
		throw new ArithmeticException("divide by zero");
	}

}
