add(X,T,[X|T]).
