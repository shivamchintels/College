member(X,[H|T]).
member(X,[H|T]):-
    member(X,T).
set([]).
set([X|T]):-
    not(member(X,T)),
    set(T).
