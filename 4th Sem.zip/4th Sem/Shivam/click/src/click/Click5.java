package click;

public class Click5 {
	
	public static void m1()throws ArithmeticException
	{
		m2();
	}
	public static void m2()
	{
		System.out.println(10/0);
	}
	public static void main(String[] args)throws ArithmeticException 
	{
		Click5 c=new Click5();
		c.m1();
	}
}
