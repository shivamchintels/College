
public class Mythread extends Thread
{
public void run()
{
	System.out.println("Shut down hookclock computer");
}
}
class TestShutdown
{
	public static void main()throws Exception
	{
		Runtime r= Runtime.getRuntime();
		r.addShutdownHook(new Mythread());
		System.out.println("Now main Sleeping, press Ctrl+C  tom exit ");
		try
		{
			Thread.sleep(3000);
		}
		catch(Exception e)
		{}
		}
	}
