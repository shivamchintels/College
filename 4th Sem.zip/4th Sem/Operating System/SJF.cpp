#include<stdio.h>
#include<conio.h>
int main()
{
	int bt[20],p[20],wt[20],tat[20],i,j,n,total=0,pos,temp;
	float avg_wt,avg_tat;
	printf("Please give Number Process");
	scanf(%d,&n);
	printf("Enter Burst time");
	for(i=0;i<n;i++)
	{
		printf("p%d",i+1);
		scanf(%d,&bt[i]);
		p[i]=i+1;
}
	for(i=0;i<n;i+=)
	pos=i;
int a=2;
int b=2;
int c;
c=a+b;
printf("%d",c);
return 0;
}
