
public class TJM extends Thread
{
public void run()
{
	System.out.println(Thread.currentThread().getName());
}
public static void main(String args[])
{
	TJM t1=new TJM();
	TJM t2=new TJM();
	System.out.println("Name of t1:"+t1.getName());
	System.out.println("Name of t2:"+t2.getName());
	System.out.println("ID of t1:"+t1.getId());
	t1.start();
	t2.start();
	t1.setName("CS 2E");
	System.out.println("After Changing name:"+t1.getName());
}
}
