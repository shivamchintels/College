lg(A,B,C):-

    (   A>B,A>C),
     write("Largest is A");

    (   B>A,B>C),
     write("Largest is B");

    (   C>A,C>B),
     write("Largest is C").




