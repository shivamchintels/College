package thread;

class thread1 implements Runnable
{
	public void run()
	{
		int a=2,b=2,c;
		c=a+b;
		System.out.println(c);
	}
}

public class Main2 {

	public static void main(String[] args) {
		thread1 t1=new thread1();
		
		

	}

}
