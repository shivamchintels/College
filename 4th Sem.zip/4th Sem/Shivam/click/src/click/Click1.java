package click;
import java.util.Scanner;


public class Click1 {
	public static void main(String[] args) {
		int a[] =new int[5];
		int i;
		Scanner sc= new Scanner (System.in);
		System.out.println("Enter Elements ");
				for(i=0;i<7;i++)
				{
					a[i]=sc.nextInt();
				}
				System.out.println("Elements are:");
				for(i=0;i<7;i++)
				{
					System.out.println(a[i]);
				}
	}
}