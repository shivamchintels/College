sumsq(1,1).
sumsq(A,R):-
    A1 is A-1,
sumsq(A1,R1),
    R is R1+(A*A).

