palin(list1):-
    findreverse(list1,[],list2),
    compare(list1,list2).

findreverse([],list,list).
findreverse([X,T],list1,list2):-
    findreverse(T,[X|list],list2).
compare([],[]):-
    write("Palindrome").
compare([X|list1],[X|list2]):-
    compare(list1,list2).


