  fact(0,1).
fact(N,R):-
    N1 is N-1,
    fact(N1,R1),
    R is N*R1.

fact(0,1).
fact(N,R):-
    N1 is N-1,
    fact(N1,R1),
    R is N*R1.
combination(N,R,A):-
    fact(N,R1),
    N1 is N-R,
    fact(N1,R2),
    N2 is R,
    fact(N2,R3),
    A is R1/(R2*R3).

pascal(N,R,A):-
    combination(N-1,R,R1),
    combination(N-1,R-1,R2),
    A is R1+R2.
