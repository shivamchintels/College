evod():-write("Enter Value"),
        read(A),
       (    A mod 2=:=0),
        write("A is even");
        write("A is odd").

