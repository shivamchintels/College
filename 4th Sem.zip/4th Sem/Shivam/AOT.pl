areatri(A,B,C):-S is (A+B+C)/2,
 X is sqrt(S*(S-A)*(S-B)*(S-C)),
 write(X).
