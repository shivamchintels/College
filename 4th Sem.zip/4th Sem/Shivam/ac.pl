ac:- write("Enter the radius"),
      read(R),
      A is 3.14*R*R,
      C is 2*3.14*R,
      write(A),
      nl,
      write(C).
