#include<stdio.h>
 
int main()
{
      int bt[20], p[20], wt[20], tat[20], pri[20];
      int i, j, n, sum = 0, pos, temp;
      float awt, atat;
      printf("Enter Total Number of Processes:\t");
      scanf("%d", &n);
      printf("\nEnter Burst Time and Priority For %d Processes\n", n);
      for(i = 0; i < n; i++)
      {
            printf("\nProcess[%d]\n", i + 1);
            printf("Process Burst Time:\t");
            scanf("%d", &bt[i]);
            printf("Process Priority:\t");
            scanf("%d", &pri[i]);
            p[i] = i + 1;
      }
      for(i = 0; i < n; i++)
      {
            pos = i;
            for(j = i + 1; j < n; j++)
            {
                  if(pri[j] < pri[pos])
                  {
                        pos = j;
                  }
            }
            temp = pri[i];
            pri[i] = pri[pos];
            pri[pos] = temp; 
            temp = bt[i];
            bt[i] = bt[pos];
            bt[pos] = temp;
            temp = p[i];
            p[i] = p[pos];
            p[pos] = temp;
      }
      wt[0] = 0;
      for(i = 1; i < n; i++)
      {
            wt[i] = 0;
            for(j = 0; j < i; j++)
            {
                wt[i] = wt[i] + bt[j];
            }
            sum = sum + wt[i];
      }
      awt = sum / n;
      sum = 0;
      printf("\nProcess ID\t\tBurst Time\t Waiting Time\t Turnaround Time\n");
      for(i = 0; i < n; i++)
      {
            tat[i] = bt[i] + wt[i];
            sum = sum + tat[i];
            printf("\nProcess[%d]\t\t%d\t\t %d\t\t %d\n", p[i], bt[i], wt[i], tat[i]);
      }
      atat = sum / n;
      printf("\nAverage Waiting Time:\t%f", awt);
      printf("\nAverage Turnaround Time:\t%f\n", atat);
      return 0;
}


