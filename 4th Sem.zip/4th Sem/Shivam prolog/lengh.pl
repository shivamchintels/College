lengh([],0).
lengh([X|T],L):-lengh(T,L1),
    L=L1+1.
number(A):- Lmod2=:=0,
    write("Even no.");
    write("Odd no.").
check([H|T]):-
    lengh([H|T],B),
    number(B).
