last([X],X).
last([H|T],R):-
    last(T|R1).
