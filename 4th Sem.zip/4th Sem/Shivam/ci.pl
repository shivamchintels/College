ci():-
    write("Enter Principle"),
    read(P),
    write("Enter Time"),
    read(N),
    write("Enter Rate"),
    read(R),
    s is ((P*R*T)/100),
    write(S),
    c is (P*((1+(R/100)^N),
            write(C).
