from re import search
list1 = [
    "TR15011",
    "FC23123",
    "TR123434",
    "FC2345234",
    "AP24524",
    "24524AP",
    "AP24524TR",
    "AP24524FC",
]
fc=[]
tr=[]
ap=[]
for i in list1:
 if (match("FC.*",i) and not match("AP.*",i) and not match("TR.*",i)):
  copy=i
    fc.append(copy)
    list1.remove(i)
 if (match("AP.*)",i) and not match("FC.*",i) and not match("TR.*",i):
  copy=i
   fc.append(copy)
   list1.remove(i)
  if (match("TR.*)",i) and not match("FC.*",i) and not match("AP.*",i): 
   copy=i
   fc.append(copy)
   list1.remove(i)  
print (fc):
print (ap):
print (tr) 