#include<stdio.h>
int main()
{
		//Inputs
		 int tat[20],bt[20],wt[20],priority[20],process[20],endtime,i,smallest;
	      //int remain=0,n,time,sum_wait=0,sum_tat=0;
	      int j,limit,sum=0,position,temp;
	      float avgtat, avgwt;
	      
		printf("\nEnter the No. of processes :");
		scanf("%d",&limit);
    //for(i=0;i<n;i++)
     //{ 
		printf("\tPlease Enter the burst time and priority of %d process :\n",limit);
	    for(i=0;i<limit;i++)
	    {
	    		printf("\n Process[%d] \n",i+1);
	    			printf("\n Process Burts Time \t");
	    			scanf("%d",&bt[i]);
	    			printf("\n Process Priority\t");
	    			scanf("%d",&priority[i]);
	    			process[i]=i+1;	    	 	
	}
	//	for(i=0;i<limit;i++)
     //{ 
	//	scanf(" %d",&bt[i]);
	//	printf("\tPlease Enter the arrival time of %d process :",i+1);
	//	scanf(" %d",&at[i]);
	  //  printf("\tPlease Enter the Priority of %d process :",i+1);
		//scanf(" %d",&pt[i]);		

for(i=0;i<limit;i++)
{
	position=i;
	for(j=1;j<limit;j++)
	{
		if(priority[j]<priority[position])
		{
		position=j;
	}}
	temp=priority[i];
	priority[i]=priority[position];
	priority[position]=temp; 
	temp=tat[i];
	bt[i]=bt[position];
	bt[position]=temp;
	temp=process[i];
	process[i]=process[position];
	process[position]=temp;
}
  wt[0]=0;
  for(i=1;i<limit;i++)
  {
  	 wt[i]=0;
  	for(i=0;i<limit;i++)
  	{
  		wt[i]=wt[i]+bt[j];
	  }
	  sum=sum+wt[i];
  }
	avgtat=sum/limit;
	sum=0;
	  printf("\n Process||\t Burst Time \t Waiting Time \t Turnaround Time \n");
	  for(i=0;i<limit;i++)
	  {
	  	tat[i]=bt[i]+wt[i];
	  	sum=sum+tat[i];
	  	printf("\n Process[%d]\t\t %d  %d \t\t %\n");
	  	process[i],bt[i],wt[i],tat[i];
	  }
	  avgtat=sum/limit;
	  printf("\Average Waiting Time:\t %f",avgwt);
	  printf("\Average Turnaround Time:\t %f \n",avgtat);
	  return 0;
}
	  
	  	
	  
	
